
<center><h2>หน้าหลัก</h2>
<input type="button" onclick="location.href='show.php';" 
value="แสดงข้อมูล">
<input type="button" onclick="location.href='in.php';" 
value="บันทึกข้อมูล">
</center>