
<?php
include"conn.php";
$sql="select * from book";
 $res=$conn->query($sql);?>
<table align="center" border="1">
    <caption>หน้าแสดงผลข้อมูล</caption>
    <tr><th>รหัสหนังสือ</th><th>ชื่อหนังสือ</th><th>ราคาหนังสือ</th><th>รหัสผู้แต่งหนังสือ</th><th>ชื่อผู้แต่ง</th><th>นามสกุลผู้แต่ง</th><th>สำนักพิมพ์</th><th>ลบ</th><th>แก้ไข</th><th>รายละเอียดข้อมูล</th></tr>

 <?php
 while($rs=$res->fetch_row()){ //ดึงข้อมูล
    print " <tr><td> $rs[0] </td><td> $rs[1] </td><td> $rs[2]</td><td> $rs[3]</td> <td> $rs[4]</td><td>  $rs[5]</td><td> $rs[6]</td><td> 
    <a href=del.php?id_book=$rs[0]> ลบ </a></td><td>  
    <a href=up.php?id_book=$rs[0]> up </a> </td><td> 
    <a href=detail.php?id_book=$rs[0]> detail </a></td></tr>";
}
?>
</table>
    <input type="button" onclick="location.href='indtx.php'" value="หน้าหลัก" >
 