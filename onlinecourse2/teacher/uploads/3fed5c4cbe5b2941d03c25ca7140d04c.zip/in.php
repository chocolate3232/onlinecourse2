
<table align="center">
    <caption>หน้าบันทึกข้อมูล</caption>
<form method="post">
 <tr><td>รหัสหนังสือ</td><td><input type="text" name="id_book" required></td></tr>
 <tr><td>ชื่อหนังสือ </td><td><input type="text" name="title"></td></tr>
 <tr><td>ราคาหนังสือ</td><td><input type="text" name="price"></td></tr>
 <tr><td>รหัสผู้เแต่ง</td><td> <input type="text" name="id_author" required></td></tr>
 <tr><td>ชื่อผู้เเต่ง</td><td><input type="text" name="fname"></td></tr>
 <tr><td>นามสกุลผู้แต่ง </td><td><input type="text" name="lname"></td></tr>
 <tr><td>สำนักพิมพ์</td><td><input type="text" name="author"></td></tr>
 
 <tr><td></td><td><input type="submit" name="ok" value="save">
 <input type="reset"  value="reset"></td></tr>
</form> 
</table>
<?php
if($_POST['ok']){
    include "conn.php";
    $id_book=$_POST['id_book'];
    $title=$_POST['title'];
    $price=$_POST['price'];
    $id_author=$_POST['id_author'];
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $author=$_POST['author'];
    $sql="insert into book values('$id_book','$title','$price','$id_author','$fname','$lname','$author')";
    $res=$conn->query($sql);
    //depart
   // $sql1="insert into depart values('$depno','','')";
    //$res1=$conn->query($sql1);
    if($res){
    print "เพิ่ม $id_book $title $price $id_author $fname $lname $author แล้ว";
        header("refresh:2;url=sh.php");
}
    else{print "เพิ่มไม่ได้ $id_book $title $price $id_author $fname $lname แล้ว";}
}
?>
    <input type="button" onclick="location.href='index.php'" value="หน้าหลัก" >