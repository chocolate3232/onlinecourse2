
<?php
include"conn.php";//1
$sql="create table book (id_book varchar(10)primary key,
 title text(100),price int(4),id_author varchar(100),fname text(60),
 lname text(60),author text(100))";//2
 $res=$conn->query($sql);//3
 if($res){
    echo"สร้างตารางเรียบร้อย";
}
 else{echo"สร้างตารางไม่ได้";
}
?>