
<?php
include "conn.php";
$id_book=$_GET['id_book'];
//$author=$_GET['author'];
$sql="delete from book where id_book='$id_book'";
$res=$conn->query($sql);
//$sql1="delete from depart where depno='$depno'";
//$res1=$conn->query($sql1);
if($res){
    echo "ลบรหัส $code เรียบร้อย";
    header("refresh:2;url=sh.php");
}else{echo "ลบรหัส $code ไม่ได้";}
?>
 <input type="button" onclick="location.href='index.php'" value="หน้าหลัก" >