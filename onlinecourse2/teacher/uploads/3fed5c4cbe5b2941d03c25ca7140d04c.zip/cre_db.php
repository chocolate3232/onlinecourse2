
<?php
include"conn.php";
$sql="create database if not exists work_book1 ";
$res=$conn->query($sql);
if($res){ 
    echo "สร้างฐานข้อมูลเรียบร้อย";
}

?>