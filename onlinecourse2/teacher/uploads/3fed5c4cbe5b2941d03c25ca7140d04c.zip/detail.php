
<?php
include"conn.php";
$empno=$_GET['empno'];
$depno=$_GET['depno'];
$sql="select * from employee where empno='$empno'";
 $res=$conn->query($sql);
 $rs=$res->fetch_row(); //ดึงข้อมูล employee
 $sql1="select * from depart where depno='$depno'";
 $res1=$conn->query($sql1);
 $rs1=$res1->fetch_row(); //ดึงข้อมูล depart
 ?>
<table align="center">
   <caption>แสดงรายละเอียดข้อมูล</caption>

 <tr><td>รหัสพนักงาน </td><td><?=$rs[0];?></td></tr>
 <tr><td>ชื่อพนักงาน </td><td><?=$rs[1];?></td></tr>
 <tr><td>นามสกุลพนักงาน </td><td><?=$rs[2];?></td></tr>
 <tr><td>ตำแหน่งพนักงาน </td><td><?=$rs[3];?></td></tr>
 <tr><td>เก็บตำแหน่งรูป </td><td><?=$rs[4];?></td></tr>
 <tr><td>รหัสแผนก </td><td><?=$rs[5];?></td></tr>
 <tr><td>ชื่อแผนก </td><td><?=$rs1[1];?></td></tr>
 <tr><td>ที่อยู่ </td><td><?=$rs1[2];?></td></tr>
   
    
    </table>

    <input type="button" onclick="location.href='index.php'" value="หน้าหลัก" >