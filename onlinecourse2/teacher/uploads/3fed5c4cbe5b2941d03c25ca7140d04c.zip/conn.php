<?php
     $conn = new mysqli ("127.0.0.1","root","11111111","work_book1");
     if ($conn->connect_error){echo"Server not run";}
?>