
<?php
if($_GET['id_book']){
    include "conn.php";
    $id_book=$_GET['id_book'];
    //$depno=$_GET['depno'];
    $sql="select * from book where id_book='$id_book'";
    $res=$conn->query($sql);
    $rs=$res->fetch_row(); } 
    //$sql1="select * from depart where depno='$depno'";
   // $res1=$conn->query($sql1);
   // $rs1=$res1->fetch_row(); ?>
    <table align="center">
      <caption>หน้าแก้ไขข้อมูล</caption>
<form method="post">
<tr><td>รหัสพนักงาน</td><td><input type="text" name="empno" value="<?=$rs[0];?>" disabled></td></tr>
<input type="hidden" name="empno" value="<?=$rs[0];?>">
 <tr><td>ชื่อพนักงาน </td><td><input type="text" name="fname" value="<?=$rs[1];?>"></td></tr>
 <tr><td>นามสกุลพนักงาน</td><td><input type="text" name="lname" value="<?=$rs[2];?>"></td></tr>
 <tr><td>ตำแหน่งพนักงาน</td><td> <input type="text" name="position" value="<?=$rs[3];?>"></td></tr>
 <tr><td>เก็บตำแหน่งรูป</td><td><input type="text" name="path" value="<?=$rs[4];?>"></td></tr>
 <tr><td>รหัสแผนก </td><td><input type="text" name="depno" value="<?=$rs1[0];?>" disabled></td></tr>
 <input type="hidden" name="depno" value="<?=$rs1[0];?>">
 <tr><td>ชื่อแผนก </td><td><input type="text" name="depname" value="<?=$rs1[1];?>"></td></tr>
 <tr><td>ที่อยู่</td><td><input type="text" name="location" value="<?=$rs1[2];?>"></td></tr>
 
 <tr><td></td><td><input type="submit" name="ok" value="save">
 <input type="reset"  value="reset"></td></tr>
</form> 
</table>
 <?php
if($_POST['ok']){
    include "conn.php";
    $empno=$_POST['empno'];    
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $position=$_POST['position'];
    $path=$_POST['path'];
    $depno=$_POST['depno'];
    $depname=$_POST['depname'];
    $location=$_POST['location'];
    $sql="update employee set fname='$fname',lname='$lname',position='$position',path='$path' where empno='$empno'";
    $res=$conn->query($sql);
    $sql1="update depart set depname='$depname',location='$location' where depno='$depno'";
    $res1=$conn->query($sql1);
    if($res){
    print "แก้ไข $empno $fname $depno แล้ว <br>";
    header("refresh:2;url=sh.php");
}
    else{print "แก้ไขไม่ได้ $empno $fname $depno <br> ";}
   }

?>
 <input type="button" onclick="location.href='index.php'" value="หน้าหลัก" >